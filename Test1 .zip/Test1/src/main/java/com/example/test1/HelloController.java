package com.example.test1;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class HelloController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private int failedAttempts = 0;
    private final int MAX_ATTEMPTS = 5;
    private boolean accountLocked = false;

    @FXML
    protected void onLoginButtonClicked() {
        if (accountLocked) {
            showAlert("Account Locked", "Sorry, Your Account is Locked!!!");
            return;
        }

        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Validation Error", "Please provide username and password.");
        } else {
            // Static username and password check
            if (username.equals("pargat") && password.equals("62845")) {
                showAlert("Login Successful", "Success!!!");
                resetLogin();
            } else {
                failedAttempts++;
                if (failedAttempts >= MAX_ATTEMPTS) {
                    accountLocked = true;
                    showAlert("Account Locked", "Sorry, Your Account is Locked!!!");
                } else {
                    showAlert("Login Failed", "Sorry, Invalid Username or Password. Attempt " + failedAttempts + " of " + MAX_ATTEMPTS);
                }
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void resetLogin() {
        usernameField.clear();
        passwordField.clear();
        failedAttempts = 0;
        accountLocked = false;
    }
}
